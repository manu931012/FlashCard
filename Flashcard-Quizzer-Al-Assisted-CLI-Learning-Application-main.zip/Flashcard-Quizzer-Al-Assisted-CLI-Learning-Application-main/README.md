# Flashcard Quizzer

Flashcard Quizzer is a lightweight, production-quality Python command-line
application for studying flashcards stored in JSON. It provides sequential,
random, and adaptive quiz modes, immediate colored feedback, and a final session
summary. The project demonstrates modular architecture, typed Python, the Strategy
and Factory design patterns, defensive data validation, and test-driven review of
AI-generated code.

## Features

- Load flashcards from either a JSON array or a `{ "cards": [...] }` wrapper.
- Validate files, JSON syntax, deck structure, required fields, and field values.
- Compare answers case-insensitively using Unicode-aware `casefold()`.
- Study in sequential, shuffled random, or adaptive retry mode.
- Show green correct feedback and red incorrect feedback in interactive terminals.
- Display total attempts, accuracy, and unique missed terms after every session.
- Optionally display running accuracy with `--stats`.
- End cleanly with `exit`, Ctrl+C, or end-of-input.
- Report expected failures without raw Python tracebacks.

## Requirements

- Python 3.8 or newer
- `pip`

The application itself uses only the Python standard library. Packages in
`requirements.txt` support testing, coverage, formatting, linting, and type
checking.

## Installation

Clone the repository, enter the project directory, and create an isolated virtual
environment:

```bash
python -m venv .venv
source .venv/bin/activate
```

On Windows, activate it with:

```powershell
.venv\Scripts\activate
```

Install the development dependencies:

```bash
python -m pip install -r requirements.txt
```

## Running the Quiz

The flashcard file is required. Sequential mode is the default:

```bash
python main.py -f data/python_basics.json
```

Choose a mode explicitly:

```bash
python main.py -f data/python_basics.json -m sequential
python main.py -f data/python_basics.json -m random
python main.py -f data/python_basics.json -m adaptive
```

Show running statistics after every answer:

```bash
python main.py -f data/python_basics.json -m adaptive --stats
```

Display all CLI options:

```bash
python main.py --help
```

Type `exit` at an answer prompt to finish early. Ctrl+C and end-of-input also end
the session safely. Submitted answers are included in the final summary; the exit
command itself is not counted as an attempt.

## Quiz Modes

### Sequential

Cards are asked once in their source-file order.

### Random

A copy of the deck is shuffled, then every card is asked once. The source list is
never mutated.

### Adaptive

Every card begins in the initial queue. An incorrectly answered card is appended to
the retry queue and continues to reappear until it is answered correctly or the
user exits. Retries count as attempts and affect accuracy.

## Flashcard File Format

Array format:

```json
[
  {"front": "CPU", "back": "Central Processing Unit"},
  {"front": "RAM", "back": "Random Access Memory"}
]
```

Wrapper-object format:

```json
{
  "cards": [
    {"front": "CPU", "back": "Central Processing Unit"},
    {"front": "RAM", "back": "Random Access Memory"}
  ]
}
```

A deck must contain at least one card. Each card must be an object with non-empty
string `front` and `back` values. Surrounding whitespace is removed during loading;
additional fields are permitted and ignored. Invalid files produce concise errors
such as:

```text
Error: Card 1 is missing required field 'back'.
```

## Session Statistics

`Total Questions` means submitted answer attempts, including adaptive retries.
Accuracy is the number of correct attempts divided by total attempts. `Missed
Terms` lists each incorrectly answered card front once, in first-missed order.

Example:

```text
Session Summary
------------------------------------------
Total Questions      | 3
Accuracy             | 66.7%
Missed Terms         | CPU
```

## Architecture

```text
main.py
  ├── utils/file_handler.py -> models.py
  ├── quiz_engine.py        -> models.py
  └── ui.py                 -> quiz_engine.py
```

- `models.py` defines flashcards and session statistics.
- `utils/file_handler.py` owns JSON loading and validation.
- `quiz_engine.py` owns strategies, factory construction, answer evaluation, and
  session coordination.
- `ui.py` owns terminal interaction and presentation.
- `main.py` owns argument parsing and application composition.

See `docs/architecture.md` for the complete behavior contract and
`docs/design_patterns.md` for pattern rationale.

## Testing and Quality

Run the tests:

```bash
python -m pytest tests/ -v
```

Generate terminal and HTML coverage reports:

```bash
python -m pytest tests/ --cov=. --cov-report=term-missing --cov-report=html
```

Run all static quality checks:

```bash
isort --check-only .
black --check .
flake8 .
mypy main.py models.py quiz_engine.py ui.py utils
```

The verified project result is 49 passing tests and 99% statement coverage. Full
evidence is recorded in `docs/quality_report.md`; the generated detailed report is
available at `htmlcov/index.html`.

## AI-Assisted Development Evidence

- `prompts.md` records the chronological requests given to the AI assistant.
- `docs/ai_edit_log.md` documents generated results, review decisions, rejected or
  corrected suggestions, outcomes, and lessons learned.
- `docs/final_report.md` reflects on the collaboration and engineering process.

AI output was treated as a draft: every change was reviewed, tested, formatted,
linted, and type-checked before acceptance.

