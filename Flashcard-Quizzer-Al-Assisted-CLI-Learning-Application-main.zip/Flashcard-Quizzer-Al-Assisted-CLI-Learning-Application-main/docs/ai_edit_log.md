# AI Edit Log

This log records meaningful interactions with OpenAI Codex during development. It
focuses on what was generated, what review found, what was accepted or rejected,
and how verification influenced the final result. The chronological request list is
maintained separately in `prompts.md`.

## Recorded Interactions

### 2026-08-27 - Requirements and Starter Repository Review

**Context:** I needed to understand the Flashcard Quizzer specification and compare
it with the supplied starter before any code was generated.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "We work on this project together. First read the instruction.txt
and understand the requirements."

**AI Response:** The AI read the specification and summarized the functional,
architectural, testing, quality, and documentation requirements. During the next
planning request, it inspected the repository and found that the starter was still
a generic task manager rather than a flashcard application.

**Changes Made:** I asked the AI to plan against the complete project rubric rather
than immediately generating application code. The planning review also separated
the required `prompts.md` from the more detailed `docs/ai_edit_log.md` deliverable.

**Reasoning:** Beginning with a traceable design reduces the risk of producing a
working quiz that nevertheless misses assessed items such as the Factory Pattern,
specific test names, code-quality commands, or AI review evidence.

**Outcome:** The requirements were decomposed into eight working phases. A conflict
was also identified: the report template asks for 2,000–3,000 words while the
rubric requires 1,000–1,500, so the rubric will be treated as authoritative.

**Lessons Learned:** Starter templates and supporting documents can disagree with
the final rubric. AI-generated plans still need to be checked against the actual
assessment source rather than accepted as complete on first review.

---

### 2026-08-27 - Phase 1 Architecture and Behavior Decisions

**Context:** Before implementation, ambiguous requirements needed concrete,
testable definitions and each module needed one clear responsibility.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Ok start phase 1."

**AI Response:** The AI proposed a modular dependency structure, defined the roles
of the loader, models, strategies, factory, engine, UI, and entry point, and turned
the rubric into acceptance criteria. It also proposed specific definitions for
adaptive retries, accuracy, missed terms, `--stats`, answer normalization, and
graceful exits.

**Changes Made:** The plan was constrained to documentation and design only; no
application code was accepted during Phase 1. The final decisions were written to
`docs/architecture.md` so implementation and tests can be reviewed against a stable
baseline.

**Reasoning:** Adaptive mode and statistics are easy to implement inconsistently.
Defining an attempt, retry ordering, uniqueness of missed terms, and early-exit
behavior now makes later tests objective rather than tailored to whatever code is
generated.

**Outcome:** Phase 1 produced a planned file structure, dependency rules, behavior
contract, requirements traceability checklist, quality gates, and known-risk list.

**Lessons Learned:** A useful AI architecture response is not only a file list. It
must resolve observable behavior and provide acceptance tests that can prove the
design was implemented correctly.

---

### 2026-08-27 - Flashcard Loader Generation and Refactoring

**Context:** Phase 2 required a typed flashcard model and a loader that accepts both
specified JSON formats while converting expected failures into helpful messages.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "continue to phase 2"

**AI Response:** The AI created an immutable `Flashcard` dataclass, a
`FlashcardDataError`, validation helpers, and tests for valid decks, malformed JSON,
missing fields, wrong types, blank fields, empty decks, missing files, and read
errors. The initial patch left the starter's generic `FileHandler` in the same
module for temporary compatibility.

**Changes Made:** After the first test pass, I reviewed the module against the Phase
1 single-responsibility decision. The obsolete generic persistence class and its
task-manager-specific tests were rejected and removed. Black and isort were then
applied, and lint and type checks were rerun on all Phase 2 files.

**Reasoning:** Keeping two unrelated loading APIs would make the module harder to
understand, preserve unused code, and inflate coverage with behavior outside the
Flashcard Quizzer's scope. Passing old tests was less valuable than maintaining a
cohesive final application.

**Outcome:** The refined loader and model pass the complete active test suite as
well as Black, isort, flake8, and mypy checks. A coverage command was attempted but
could not run because `pytest-cov`, although declared in `requirements.txt`, is not
installed in the active environment. This dependency gap will be resolved before
the final quality gate.

**Lessons Learned:** Backward compatibility with irrelevant starter examples can
conflict with separation of concerns. AI-generated code should be judged against
the target product architecture, not merely by whether all inherited tests remain
green.

---

### 2026-08-27 - Quiz Strategies, Factory, and Tooling Review

**Context:** Phase 3 required interchangeable card-selection algorithms with an
adaptive mode that safely repeats incorrect cards.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Continue to phase 3"

**AI Response:** The AI generated the abstract `QuizMode` contract, a shared
queue-backed lifecycle implementation, sequential, random, and adaptive concrete
strategies, and a factory that normalizes user-facing names. Tests covered each
factory result, ordering, deterministic shuffling, defensive copying, repeated
adaptive failures, empty decks, and invalid method order.

**Changes Made:** I validated that a caller cannot request a second card before
recording the first result, preventing silent card loss. During the quality pass,
I also rejected the assumption that independently running default isort and Black
would produce stable formatting. Their multiline-import styles conflicted, so a
shared Black-compatible isort profile was added to `pyproject.toml` and both checks
were rerun.

**Reasoning:** Strategy objects are stateful, so their lifecycle is part of their
correctness contract. Tooling must also be deterministic: a repository cannot claim
to pass both formatters if each formatter undoes the other's output.

**Outcome:** All three strategies and the factory pass their unit tests. The active
suite contains 34 passing tests, and Phase 3 passes Black, isort, flake8, and mypy.

**Lessons Learned:** Tests should cover invalid call sequences as well as expected
algorithms. Code-quality tools also need explicit compatible configuration rather
than relying on defaults.

---

### 2026-08-27 - Session Engine, CLI, and Test Expectation Review

**Context:** Phase 4 connected the strategies to answer evaluation, session
statistics, terminal presentation, and command-line arguments while preserving
separation of concerns.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Continue to phase 4"

**AI Response:** The AI added `SessionStats`, `QuizEngine`, an injectable
`TerminalUI`, and a real `argparse` entry point. It generated tests for normalized
answers, adaptive attempt statistics, engine lifecycle errors, summaries, running
stats, ANSI colors, `exit`, Ctrl+C, EOF, parser defaults, invalid modes, and missing
files. It also removed the remaining task-manager demonstration source and tests.

**Changes Made:** The first run had two failing assertions. Review showed the
implementation was correct: 1/3 accuracy is `33.333333...`, while the test expected
an unnecessarily precise match around `33.333`; another test expected one extra
space in a width-20 summary column. I corrected both tests instead of distorting
production calculations or layout. I also configured isort to ignore supplied
extensionless `.claude/commands` prompt assets and formatted the package marker
files found by the repository-wide Black check.

**Reasoning:** A failing test is evidence to investigate, not automatic proof that
production code is wrong. Changing correct code to satisfy an incorrect assertion
would introduce a real defect. Quality tools should inspect owned source while
leaving non-Python instructional assets untouched.

**Outcome:** The interactive architecture is complete, expected startup errors are
friendly, and all 41 active tests pass. Repository-wide isort, Black, and flake8
checks pass, as does mypy for all application modules.

**Lessons Learned:** AI can generate incorrect tests as easily as incorrect
application code. Expected numeric precision and formatted-output spacing must be
reviewed against the actual specification before choosing which side to change.

---

### 2026-08-27 - Integration Scope and Real CLI Verification

**Context:** Phase 5 needed evidence that independently tested modules work together
through the same entry point a user runs, plus a valid sample deck for submission.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Continue to phase 5"

**AI Response:** The AI created an eight-card Python basics deck and integration
tests for a three-question session, adaptive retry, running stats, early exit,
malformed JSON, a missing required field, and an empty deck. It also added focused
engine tests for Unicode case folding and significant internal whitespace.

**Changes Made:** I kept random ordering out of answer-sequence integration tests
because uncontrolled shuffling would make them flaky. Random behavior remains
covered at the strategy boundary with an injected seeded generator, while the full
CLI tests use deterministic sequential and adaptive modes. I then ran the actual
required adaptive command in a terminal and intentionally missed the first card to
confirm it reappeared after all initially queued cards.

**Reasoning:** Integration tests should cross meaningful module boundaries without
introducing nondeterminism. A manual terminal run additionally verifies prompt
rendering and ANSI colors, which captured test output deliberately disables.

**Outcome:** The active suite has 49 passing tests. The complete adaptive CLI run
asked eight initial cards plus one retry, displayed colored feedback, and reported
9 questions, 88.9% accuracy, and the correct missed term. Current isort, Black,
flake8, and mypy checks also pass.

**Lessons Learned:** Unit and integration tests have different responsibilities.
Injectable randomness makes algorithm tests stable, while a small deterministic
end-to-end deck makes failures easy to understand and maintain.

---

### 2026-08-27 - Coverage Tooling and Quality-Gate Audit

**Context:** Phase 6 had to prove the rubric's coverage threshold and run every
automated and manual quality check against the assembled application.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Continue to phase 6"

**AI Response:** The AI ran repository-wide isort, Black, flake8, mypy, and pytest,
then checked for coverage support. It found that `pytest-cov` was declared but not
installed. After a sandboxed installation failed because network access was
restricted, it requested permission and installed the tool into `/tmp`, generated
terminal and HTML reports, and exercised every mode in a real terminal.

**Changes Made:** I kept the coverage installation isolated rather than altering
the global Python environment. After verifying that the application has no runtime
third-party imports, I removed unused optional starter packages from
`requirements.txt`. I also required both application-only and rubric-shaped
whole-project coverage commands so the reported percentage was not dependent on a
single favorable configuration.

**Reasoning:** A dependency listed in a file is not evidence that the active test
environment actually provides it. Coverage should focus on production modules, but
running the exact `--cov=.` shape also proves that the rubric command succeeds.
Removing unused dependencies reduces installation time and future compatibility or
security risk.

**Outcome:** Forty-nine tests pass. Application-only and whole-project statement
coverage are both 99%. All code-quality checks pass, every quiz mode starts
correctly, sequential and adaptive sessions complete, and both `exit` and Ctrl+C
end cleanly. Detailed evidence is recorded in `docs/quality_report.md` and
`htmlcov/index.html`.

**Lessons Learned:** Verification includes the tooling environment as well as the
code. Isolated installation, two coverage views, and real terminal checks produce
stronger evidence than relying on a single test command.

---

### 2026-08-27 - Project Documentation and Report Review

**Context:** Phase 7 had to replace the generic starter narrative with accurate
documentation for users, reviewers, and future maintainers.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Continue to phase 7"

**AI Response:** The AI rewrote the README with setup, JSON schemas, all CLI modes,
statistics definitions, architecture, quality commands, and collaboration evidence.
It replaced the generic design-pattern examples with the actual Strategy and Factory
implementation and drafted the final report from the documented development record.

**Changes Made:** I prioritized the rubric's 1,000–1,500-word limit over the stale
2,000–3,000-word note in the report template. The report was measured at 1,243 words.
The generic TaskManager example and unfilled instructional prompts were removed from
this log, while all genuine review entries were retained. I did not infer a student
identity from filesystem paths, leaving one clearly marked report-header field for
the student to personalize.

**Reasoning:** Submission documentation must describe the delivered product rather
than the starter. Claims about tests, coverage, and review should be traceable to
recorded evidence, and personal identity should not be guessed from environment
metadata.

**Outcome:** The project now has a product README, an application-specific pattern
guide, a rubric-length final report, ten chronological prompts, and eight detailed
review entries. All commands documented in the README match verified behavior.

**Lessons Learned:** Documentation generated from a maintained decision log is more
accurate than reconstructing rationale at the end. Conflicting templates require an
explicit source-of-truth decision.

---

### 2026-08-27 - Final Rubric and Submission Audit

**Context:** Phase 8 had to confirm that passing code, generated evidence, and Git
submission contents all matched the rubric rather than merely existing locally.

**AI Tool Used:** OpenAI Codex

**Prompt/Request:** "Continue to phase 8"

**AI Response:** The AI inspected all source and deliverable files, matched the six
required test names, reran repository-wide checks, reviewed placeholder and legacy
references, checked Git state, and produced a submission audit. It found that the
starter `.gitignore` excluded both `data/` and `htmlcov/`.

**Changes Made:** I removed those two ignore rules and the coverage generator's
nested ignore file so the sample deck and coverage evidence can be submitted. I
added `.venv/` and `.mypy_cache/` to retain appropriate generated-file exclusions.
After managed filesystem restrictions blocked `git init`, I approved that narrowly
scoped local operation. No files were staged, committed, or published.

**Reasoning:** An artifact that exists locally but is ignored by Git will be absent
from the submitted repository. Final review must inspect inclusion rules and
external-state prerequisites, not only source behavior. Publishing and personal
identity remain user decisions and should not be assumed.

**Outcome:** The project is a local Git repository on `main`; required data and HTML
coverage files are visible to Git, caches are ignored, and all 49 tests, isort,
Black, flake8, and mypy pass. The audit identified only two user-owned actions. Its
internal checklist file was later removed from the submission contents at the
user's request because the rubric does not require it.

**Lessons Learned:** Submission packaging is a distinct engineering phase. Ignore
rules, generated evidence, repository state, identity, and remote publication can
invalidate otherwise complete work if they are not audited explicitly.

---

## Summary Statistics

- **Chronological prompts recorded:** 11
- **Detailed review entries:** 9
- **Application source reviewed:** 461 lines
- **Test source reviewed:** 692 lines
- **Automated tests:** 49 passing
- **Statement coverage:** 99%
- **Most valuable interaction:** Phase 1 behavior and architecture definition
- **Most challenging interaction:** Distinguishing incorrect generated tests from
  correct production behavior in Phase 4
- **Biggest lesson:** Treat AI output, including tests, as a hypothesis that must be
  checked against explicit requirements and independent evidence.
