# Flashcard Quizzer Architecture and Acceptance Criteria

## 1. Project Scope

The Flashcard Quizzer is a lightweight Python command-line application. It loads
flashcards from JSON, quizzes the user in one of three modes, provides immediate
feedback, and reports session statistics. The implementation must demonstrate
responsible AI-assisted development, modular design, strong input validation,
automated testing, and documented code review.

This document is the Phase 1 design baseline. If implementation reveals that a
decision needs to change, the change and its reason will be recorded in
`docs/ai_edit_log.md`.

## 2. Planned Project Structure

```text
starter/
├── main.py                     # Argument parsing and application composition
├── models.py                   # Flashcard and session-statistics data models
├── quiz_engine.py              # Quiz strategies, factory, and session engine
├── ui.py                       # Terminal input, output, colors, and summaries
├── utils/
│   ├── __init__.py
│   └── file_handler.py         # JSON loading and flashcard validation
├── data/
│   └── python_basics.json      # Valid sample deck
├── tests/
│   ├── __init__.py
│   ├── test_flashcard_loader.py
│   ├── test_quiz_modes.py
│   ├── test_quiz_engine.py
│   ├── test_ui.py
│   └── test_integration.py
├── docs/
│   ├── ai_edit_log.md
│   ├── architecture.md
│   ├── design_patterns.md
│   ├── final_report.md
│   └── project_rubric.md
├── prompts.md
├── requirements.txt
└── README.md
```

The existing directory structure will be preserved. Generic task-manager starter
code and tests will be replaced when the relevant implementation phases begin so
that the submitted application has one clear purpose and coverage is meaningful.

## 3. Module Responsibilities

### `models.py`

- Defines an immutable, typed `Flashcard` value object.
- Defines typed session-statistics data.
- Contains data only; it performs no terminal or file I/O.

### `utils/file_handler.py`

- Reads UTF-8 JSON from the exact path supplied by the user.
- Supports array and `{ "cards": [...] }` input formats.
- Validates the complete deck before returning it.
- Converts expected file and data failures into a friendly domain exception.
- Performs no printing, prompting, or quiz logic.

### `quiz_engine.py`

- Defines the abstract `QuizMode` Strategy interface.
- Implements sequential, random, and adaptive strategies.
- Defines `QuizModeFactory` for selecting a strategy from CLI input.
- Compares answers and maintains session statistics.
- Performs no direct terminal input or output.

### `ui.py`

- Runs the interactive terminal loop against the engine's public interface.
- Renders questions, colored feedback, running statistics, and final summaries.
- Recognizes `exit`, Ctrl+C, and end-of-input without exposing a traceback.
- Keeps presentation choices separate from quiz algorithms.

### `main.py`

- Defines the `argparse` interface.
- Loads the deck and constructs the selected mode, engine, and UI.
- Maps expected failures to concise user-facing messages and exit codes.
- Contains no validation or quiz algorithm implementation.

## 4. Dependency Flow

```text
main.py
  ├── utils.file_handler ──> models
  ├── quiz_engine ─────────> models
  └── ui ──────────────────> quiz_engine
```

Dependencies point toward data and domain logic. The engine does not depend on the
terminal UI, allowing tests to exercise quiz behavior without patching `input()` or
capturing ANSI output.

## 5. Design Patterns

### Strategy Pattern

`QuizMode` defines the shared contract for selecting questions and recording
results. `SequentialMode`, `RandomMode`, and `AdaptiveMode` supply different
algorithms behind that interface. The engine therefore works with any conforming
mode and can later support spaced repetition without being rewritten.

### Factory Pattern

`QuizModeFactory` owns the mapping from a normalized mode name to a concrete
strategy. Argument parsing validates common CLI mistakes, while the factory also
rejects invalid values when called directly. This avoids spreading construction
conditionals through the application.

## 6. Resolved Behavior Decisions

### JSON validation

- Accepted top-level formats are a list of cards or an object whose `cards` value
  is a list.
- A card must be a JSON object with `front` and `back` keys.
- Both values must be non-empty strings after surrounding whitespace is removed.
- Leading and trailing whitespace is removed when cards are loaded.
- Extra card fields are ignored to keep the input format extensible.
- An empty deck is invalid because an interactive quiz cannot use it.
- The loader validates the whole deck and reports the first invalid card with its
  one-based position.
- Missing, unreadable, malformed, or invalid files result in a helpful message and
  a non-zero exit code, never an expected-error traceback.

### Answer comparison

- User answers are stripped of surrounding whitespace and compared with
  `casefold()` rather than `lower()` for robust case-insensitive text handling.
- Internal whitespace and punctuation remain significant; silently rewriting them
  could incorrectly accept a different answer.
- A blank answer is a legitimate incorrect attempt rather than a program error.

### Mode behavior

- Sequential mode asks each card exactly once in file order.
- Random mode shuffles a copy of the deck and asks each card exactly once.
- Randomness is injectable so tests can be deterministic.
- Adaptive mode begins in file order and asks every card at least once.
- An incorrectly answered adaptive card is appended to the retry queue.
- The mode ends after every card has eventually been answered correctly, or when
  the user exits.
- Every retry is an attempt and contributes to statistics.

### Statistics

- `total_questions` is the number of submitted answers, including adaptive retries.
- `correct_answers` is the number of attempts answered correctly.
- Accuracy is `(correct_answers / total_questions) * 100`, displayed to one decimal
  place. A session with no attempts has 0.0% accuracy.
- Missed terms are unique card fronts answered incorrectly at least once, listed in
  first-missed order.
- A final summary is always displayed for a completed or intentionally ended
  session.
- `--stats` additionally displays running progress after each submitted answer.

### Exiting and errors

- An answer equal to `exit`, ignoring case and surrounding whitespace, ends the
  session cleanly without counting as an attempt.
- Ctrl+C and end-of-input end the session cleanly without a traceback.
- Expected data and usage errors are printed to standard error.
- A normal completed session returns exit code 0. An intentional early exit also
  returns 0 because it is a supported interaction. Configuration or data errors
  return a non-zero code.

### Terminal colors

- Correct feedback is green and incorrect feedback is red using ANSI escape codes.
- Color rendering is isolated in the UI and can be disabled for deterministic tests
  and terminals that do not support it.
- Information must remain understandable without relying on color alone.

## 7. Requirements Traceability and Acceptance Checklist

### Functional requirements

- [x] Load and validate a deck from a supplied filesystem path. CLI wiring remains
  for Phase 4.
- [x] Accept both required JSON formats.
- [x] Convert missing, malformed, and structurally invalid data into friendly
  domain errors. CLI rendering remains for Phase 4.
- [x] Present each card's front and accept a text answer.
- [x] Compare answers case-insensitively and provide immediate feedback.
- [x] Sequential mode follows file order.
- [x] Random mode asks every card in shuffled order without mutating the source
  deck.
- [x] Adaptive mode repeats incorrectly answered cards.
- [x] Final output includes total questions, accuracy, and missed terms.
- [x] `exit`, Ctrl+C, and end-of-input do not produce tracebacks.

### Technical requirements

- [x] Application code is split by responsibility across multiple modules.
- [x] Quiz modes implement an abstract Strategy interface.
- [x] A Factory selects concrete quiz modes.
- [x] All application functions and methods have Python type hints.
- [x] Public modules, classes, functions, and methods have useful docstrings.
- [x] The CLI uses `argparse` and supports `-f`, `-m`, and `--stats`.
- [x] Correct and incorrect feedback uses green and red respectively.
- [x] The current implementation passes Black, isort, and flake8.
- [x] The current application modules pass mypy without errors.

### Testing requirements

- [x] The three specifically named loader tests exist and pass.
- [x] The factory and adaptive behavior tests exist and pass.
- [x] A three-question full-session integration test exists and passes.
- [x] Happy paths, edge cases, and expected errors are tested.
- [x] Statement coverage is greater than 80%; measured application coverage is 99%.
- [x] Manual smoke tests cover all modes, `exit`, and Ctrl+C.

### Documentation and submission requirements

- [x] `prompts.md` records specific AI prompts.
- [x] `docs/ai_edit_log.md` contains eight meaningful reviewed interactions.
- [x] The README describes installation, features, input formats, and usage.
- [x] The final report follows the supplied sections and is 1,243 words.
- [x] The report explains the practical value of Strategy and Factory.
- [x] Final test, coverage, lint, formatting, and type-check results are recorded in
  `docs/quality_report.md`.
- [x] The project is initialized as a local Git repository on `main`; remote
  publication remains a user-owned submission action.

## 8. Quality Gates

The project is not complete until all commands succeed:

```bash
black --check .
isort --check-only .
flake8 .
mypy .
python -m pytest tests/ -v
python -m pytest --cov=. --cov-report=term-missing --cov-report=html
```

The following manual acceptance command must start a playable quiz:

```bash
python main.py -m adaptive -f data/python_basics.json
```

## 9. Known Project Risks

- The report template requests 2,000–3,000 words, but `instruction.txt` and the
  assessment rubric require 1,000–1,500. The rubric takes precedence, so the target
  will be approximately 1,300–1,450 words.
- The current directory is not recognized as a Git worktree. Repository setup or
  connection to the intended GitHub repository will be handled during submission
  preparation, not assumed during implementation.
- `pytest-cov` is declared in `requirements.txt` but is not installed in the active
  environment. The coverage gate must be run after development dependencies are
  installed.
- Adaptive retry logic can run indefinitely when answers remain wrong. This is
  intentional learning behavior, bounded by the supported `exit` and interrupt
  paths, and will be explicitly tested.
