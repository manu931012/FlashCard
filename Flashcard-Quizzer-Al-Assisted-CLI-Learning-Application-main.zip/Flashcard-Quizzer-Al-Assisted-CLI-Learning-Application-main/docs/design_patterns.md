# Design Patterns in Flashcard Quizzer

## Strategy Pattern

The application needs three algorithms for the same responsibility: deciding which
card should be asked next. `QuizMode` in `quiz_engine.py` defines that shared
contract:

```python
class QuizMode(ABC):
    @abstractmethod
    def get_next_card(self) -> Optional[Flashcard]:
        """Return the next card, or None when complete."""

    @abstractmethod
    def record_result(self, is_correct: bool) -> None:
        """Record the result for the current card."""
```

The concrete strategies are:

- `SequentialMode`, which consumes the original order once.
- `RandomMode`, which shuffles and consumes a defensive copy once.
- `AdaptiveMode`, which appends an incorrectly answered card to its retry queue.

All three share lifecycle safeguards through `_QueueQuizMode`. A result must be
recorded before another card can be requested, preventing accidental card loss.
`QuizEngine` depends only on the `QuizMode` abstraction, so it does not contain a
conditional for each algorithm.

This pattern serves a practical purpose: a future `SpacedRepetitionMode` can
implement the same two operations and work with the existing engine and UI. Answer
evaluation, statistics, and terminal presentation do not need to change.

## Factory Pattern

`QuizModeFactory.create_mode()` translates a user-facing name into the appropriate
strategy. It normalizes surrounding whitespace and letter case, constructs the
strategy, and rejects unsupported values with a useful list of choices.

```python
mode = QuizModeFactory.create_mode("adaptive", cards)
engine = QuizEngine(mode)
```

Object construction is therefore centralized rather than duplicated in the CLI,
tests, or UI. The mapping also makes supported modes visible in one place. Random
mode accepts an optional `random.Random` instance through the factory, allowing its
shuffle to be deterministic in tests without weakening production randomness.

## Why Other Patterns Were Not Added

The project deliberately avoids patterns that do not solve a current problem. A
Singleton would introduce global state and make isolated tests harder. Observer and
Command abstractions would add indirection to a synchronous terminal loop without
providing useful behavior. Strategy and Factory meet the rubric while improving
extensibility and testability rather than serving as decorative architecture.

## Supporting Design Principles

Although they are not named GoF patterns, several structural decisions reinforce
the design:

- Dependency injection supplies terminal input/output and random generation.
- A domain-specific `FlashcardDataError` separates expected data failures from
  programming errors.
- Immutable `Flashcard` values prevent strategies from altering deck contents.
- Defensive copies protect caller-owned card sequences.
- Separation of concerns keeps JSON, algorithms, statistics, presentation, and CLI
  composition independently testable.

