# AI-Assisted Development Project Report

**Student Name:** Hassan Jamila 
**Project Title:** Flashcard Quizzer  
**Date:** 27 August 2026

## Executive Summary

I built Flashcard Quizzer, a Python command-line application that loads study cards
from JSON and quizzes a user in sequential, random, or adaptive mode. It validates
input before a session starts, compares answers without case sensitivity, gives
immediate colored feedback, and displays total attempts, accuracy, and missed terms.
Adaptive mode repeats incorrectly answered cards until they are answered correctly,
making the application more useful than a simple one-pass reader.

OpenAI Codex assisted with requirements decomposition, architecture, implementation,
tests, review, and documentation. I treated its output as proposed code rather than
an authority. Each phase ended with tests and static checks, and problems were
recorded in `docs/ai_edit_log.md`. This process produced 49 passing tests, 99%
statement coverage, and clean isort, Black, flake8, and mypy results.

## Project Overview

The application addresses a straightforward need: people often maintain small sets
of terms or questions but do not need a graphical flashcard service. A local CLI is
fast, portable, easy to automate, and appropriate for internal material. JSON keeps
decks human-readable and makes them simple to generate or share.

The design separates data, algorithms, session state, presentation, and application
composition. `models.py` defines immutable flashcards and session statistics.
`utils/file_handler.py` reads and validates JSON. `quiz_engine.py` contains quiz
strategies, factory construction, answer normalization, and attempt tracking.
`ui.py` handles prompts, colors, exits, and summaries. `main.py` handles only command
line arguments, object construction, and friendly startup errors.

The finished features include two accepted JSON layouts, three quiz modes, adaptive
retries, Unicode-aware answer comparison, optional running statistics, colored
feedback, final summaries, and graceful `exit`, Ctrl+C, and EOF handling. Missing,
unreadable, malformed, empty, or structurally invalid decks produce concise messages
instead of tracebacks.

## AI Collaboration Workflow

The work was divided into eight phases. I first asked Codex to read the instructions
and map the rubric. That review found that the starter was a generic task manager
and that the report template conflicted with the rubric on word count. We selected
the rubric's 1,000–1,500-word requirement and documented observable behavior before
coding, including what constitutes an adaptive retry, an attempt, accuracy, and a
missed term.

Prompts then focused on one bounded milestone at a time: data loading, quiz modes,
session interaction, integration tests, and quality gates. After generation, I ran
the code and reviewed it against the architecture and supplied code-review
checklist. The complete prompt history is in `prompts.md`, while the edit log records
the response, changes, reasoning, outcome, and lesson for each meaningful
interaction.

Several interactions show why review mattered. The first loader implementation
retained the obsolete generic `FileHandler`. Although inherited tests passed, the
class violated the new module's single responsibility and inflated the product with
unused behavior, so it and its task-manager tests were removed. In the Strategy
phase, invalid lifecycle tests were added so a caller cannot request another card
before recording the current result. This protects stateful queues from silently
losing questions.

AI-generated tests also required correction. One accuracy assertion compared one
third with an overly narrow approximation centered on `33.333`; another miscounted
padding in the summary table. I verified the production calculations and formatting
before changing the assertions. Altering correct application behavior merely to
satisfy incorrect tests would have created defects. Tooling needed similar review:
default isort and Black disagreed about multiline imports, so a Black-compatible
isort profile was configured. Later, isort tried to parse supplied extensionless AI
prompt assets, which were correctly excluded rather than rewritten.

## Software Engineering Practices

The principal pattern is Strategy. `QuizMode` defines card selection and result
recording, while `SequentialMode`, `RandomMode`, and `AdaptiveMode` implement
different algorithms. `QuizEngine` depends on the abstraction, so adding spaced
repetition would not require rewriting scoring or the UI. A Factory maps normalized
mode names to strategies and centralizes construction. These patterns solve real
variation in the application rather than adding ceremonial classes.

Type hints and docstrings cover application functions and methods. Flashcards are
frozen dataclasses, strategies copy incoming decks, randomness can be injected, and
terminal I/O is injectable. Those choices reduce side effects and make tests
deterministic. The loader validates the entire deck and raises a domain-specific
exception; only the CLI converts it into user-facing output. This keeps presentation
out of data logic while ensuring expected failures never reveal a stack trace.

Testing combines focused unit tests and end-to-end integration tests. Loader tests
cover both formats, bad syntax, missing files, wrong structures, missing fields,
wrong types, blank strings, and unreadable paths. Strategy tests cover ordering,
copying, deterministic shuffling, retries, empty input, factory errors, and invalid
call sequences. Engine and UI tests cover normalization, accuracy, unique missed
terms, colors, summaries, running stats, `exit`, Ctrl+C, and EOF. The required
three-question integration test passes through the real loader, factory, engine,
UI, and CLI composition path. Random ordering remains a seeded unit test instead of
a flaky answer-sequence integration test.

The final automated result is 49 passing tests and 99% statement coverage. All
application modules except the direct-script launcher have 100% coverage; `main.py`
has 96%. isort, Black, flake8, and mypy pass. Manual terminal tests completed
sequential and adaptive sessions, started a shuffled random session, displayed ANSI
colors, and confirmed clean `exit` and Ctrl+C behavior.

## Code Quality Analysis

The final implementation contains 461 lines of application source and 692 lines of
test source. Forty-nine tests exercise 215 production statements with one uncovered
launcher statement. I rate readability 5/5 because responsibilities and names are
explicit; maintainability 5/5 because algorithms are replaceable and dependencies
are injected; test quality 5/5 because behavior, errors, misuse, and integration are
covered; and documentation 4/5 because it is complete for current behavior but would
need versioned release notes as the application evolves. These scores are supported
by automated results rather than standing alone as subjective claims.

## Technical Challenges and Solutions

The hardest logic decision was defining adaptive completion. Requeuing a missed card
immediately could starve unseen cards, while never retrying during the session would
not be meaningfully adaptive. Appending it after the initial queue ensures every
card is seen before retries and continues until mastery or a supported exit. Counting
each retry as an attempt makes accuracy honest, while storing missed fronts uniquely
keeps the summary readable.

Another challenge was separating environmental failures from product failures.
Coverage initially could not run because the declared plugin was absent. Installing
it in an isolated temporary target allowed verification without changing the global
Python installation. This showed that reproducibility includes checking actual tool
availability, not only maintaining a requirements file.

## Learning Outcomes and Reflection

The strongest use of AI was broad coverage generation and rapid decomposition. Its
weakness was local optimization: retaining irrelevant starter compatibility,
assuming formatter defaults cooperate, and writing plausible but inaccurate test
expectations. Specific prompts, small phases, explicit behavior contracts, and
immediate verification made those weaknesses manageable.

If I extended the project, I would persist performance between sessions and add a
spaced-repetition strategy based on due dates and confidence. I would also add deck
metadata and optional CSV export. The current abstractions support those additions
without coupling them to terminal presentation.

## Conclusion

This project changed AI assistance from a code-generation shortcut into a reviewable
engineering workflow. The important skill was not accepting code quickly; it was
defining behavior, constraining each request, checking assumptions, testing edge
cases, and recording why suggestions were accepted or rejected. The result is a
small but extensible CLI whose architecture, tests, quality evidence, and
documentation all trace back to the rubric.
