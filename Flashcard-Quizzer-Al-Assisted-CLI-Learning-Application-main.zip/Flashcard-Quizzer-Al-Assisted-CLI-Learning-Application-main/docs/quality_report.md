# Flashcard Quizzer Quality Report

**Verification date:** 2026-08-27  
**Python version:** 3.13.9  
**Test framework:** pytest

## Automated Quality Gates

The following commands completed successfully from the project root:

```bash
isort --check-only .
black --check .
flake8 .
mypy --no-incremental main.py models.py quiz_engine.py ui.py utils
python -m pytest tests/ -q
python -m pytest tests/ --cov=. --cov-report=term-missing --cov-report=html -q
```

Results:

| Check | Result |
|---|---:|
| Tests | 49 passed |
| Whole-project statement coverage | 99% |
| Application-only statement coverage | 99% |
| isort | Passed |
| Black | Passed |
| flake8 | Passed |
| mypy | Passed |

## Application Coverage

| Module | Statements | Missed | Coverage |
|---|---:|---:|---:|
| `main.py` | 26 | 1 | 96% |
| `models.py` | 22 | 0 | 100% |
| `quiz_engine.py` | 73 | 0 | 100% |
| `ui.py` | 53 | 0 | 100% |
| `utils/file_handler.py` | 41 | 0 | 100% |
| **Total** | **215** | **1** | **99%** |

The only uncovered application statement is the direct-script launcher in
`main.py`. Tests invoke `main(arguments)` directly so they can assert return codes
and output without starting a subprocess. The generated detailed report is at
`htmlcov/index.html`.

## Manual Acceptance Tests

### Adaptive mode

Command:

```bash
python main.py -m adaptive -f data/python_basics.json
```

The first card was intentionally answered incorrectly. It reappeared after the
initial queue and was then answered correctly. The session completed with nine
attempts, 88.9% accuracy, and the first card listed under missed terms.

### Sequential mode and running statistics

Command:

```bash
python main.py -m sequential -f data/python_basics.json --stats
```

All eight cards were answered correctly. Running progress appeared after every
answer and the final summary reported eight questions, 100.0% accuracy, and no
missed terms.

### Random mode and `exit`

Command:

```bash
python main.py -m random -f data/python_basics.json
```

The first displayed card differed from the first source card, demonstrating the
shuffled strategy. Entering `exit` ended the session cleanly with a zero-attempt
summary and no traceback.

### Ctrl+C

Ctrl+C was pressed while the sequential prompt was awaiting input. The application
printed “Quiz ended early,” displayed a zero-attempt summary, and exited without a
traceback.

## Dependency Review

The application uses only the Python standard library at runtime. `requirements.txt`
now contains only the testing, coverage, formatting, linting, and type-checking
tools required to reproduce this report. Unused starter dependencies for web
requests, CLI frameworks, validation frameworks, documentation generation, and
security scanning were removed.
