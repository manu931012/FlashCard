"""Command-line entry point for the Flashcard Quizzer."""

import argparse
import sys
from typing import Optional, Sequence

from quiz_engine import QuizEngine, QuizModeFactory
from ui import TerminalUI
from utils.file_handler import FlashcardDataError, load_flashcards


def build_parser() -> argparse.ArgumentParser:
    """Build and return the command-line argument parser."""

    parser = argparse.ArgumentParser(
        description="Quiz yourself with flashcards loaded from a JSON file."
    )
    parser.add_argument(
        "-f",
        "--file",
        required=True,
        help="path to a JSON flashcard deck",
    )
    parser.add_argument(
        "-m",
        "--mode",
        choices=("sequential", "random", "adaptive"),
        default="sequential",
        help="question order (default: sequential)",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="show running accuracy after every answer",
    )
    return parser


def main(arguments: Optional[Sequence[str]] = None) -> int:
    """Parse arguments, construct the application, and run one quiz session."""

    args = build_parser().parse_args(arguments)

    try:
        cards = load_flashcards(args.file)
        mode = QuizModeFactory.create_mode(args.mode, cards)
    except (FlashcardDataError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2

    engine = QuizEngine(mode)
    terminal = TerminalUI(
        engine,
        show_running_stats=args.stats,
        use_color=sys.stdout.isatty(),
    )
    terminal.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
