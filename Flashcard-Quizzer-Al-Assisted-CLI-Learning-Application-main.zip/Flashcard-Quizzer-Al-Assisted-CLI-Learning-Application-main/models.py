"""Domain models for the Flashcard Quizzer."""

from dataclasses import dataclass, field
from typing import List


@dataclass(frozen=True)
class Flashcard:
    """A validated flashcard with a question and expected answer."""

    front: str
    back: str


@dataclass
class SessionStats:
    """Mutable statistics collected during one quiz session."""

    total_questions: int = 0
    correct_answers: int = 0
    missed_terms: List[str] = field(default_factory=list)

    @property
    def accuracy(self) -> float:
        """Return the percentage of submitted answers that were correct."""

        if self.total_questions == 0:
            return 0.0
        return (self.correct_answers / self.total_questions) * 100

    def record_attempt(self, card: Flashcard, is_correct: bool) -> None:
        """Add one answer attempt and retain unique missed terms in order."""

        self.total_questions += 1
        if is_correct:
            self.correct_answers += 1
        elif card.front not in self.missed_terms:
            self.missed_terms.append(card.front)
