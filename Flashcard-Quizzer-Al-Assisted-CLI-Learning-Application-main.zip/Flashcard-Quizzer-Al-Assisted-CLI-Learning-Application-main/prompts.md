# AI Prompt Log

This file records the prompts used while building the Flashcard Quizzer. Detailed
review decisions, changes, and lessons learned are maintained separately in
`docs/ai_edit_log.md`.

## Interaction 1 — Requirements Review

**Date:** 2026-08-27

**Prompt:**

> We work on this project together. First read the instruction.txt and understand
> the requirements.

**Purpose:** Establish the project scope before making changes.

**Result:** The AI reviewed the complete specification and identified the required
CLI behavior, JSON formats, design patterns, testing target, quality checks, and
documentation deliverables.

## Interaction 2 — Rubric-Aligned Planning

**Date:** 2026-08-27

**Prompt:**

> Ok now plan how to do this project and meet all the points of the project rubric.

**Purpose:** Decompose the project into implementation, verification, and
documentation work.

**Result:** The AI inspected the starter repository and proposed an eight-phase
plan covering architecture, implementation, testing, quality gates, documentation,
and final submission review.

## Interaction 3 — Clarifying the Plan Structure

**Date:** 2026-08-27

**Prompt:**

> I mean 1. Establish the architecture and acceptance criteria 2. Define ambiguous
> behavior before implementation.

**Purpose:** Clarify whether the two planning activities were separate development
phases.

**Result:** Both activities were grouped under Phase 1 because they are closely
related planning tasks that must be completed before implementation begins.

## Interaction 4 — Begin Phase 1

**Date:** 2026-08-27

**Prompt:**

> Ok start phase 1.

**Purpose:** Authorize creation of the architecture, behavior definitions,
acceptance criteria, and initial AI collaboration records.

**Result:** Phase 1 produced the architecture baseline, resolved behavior contract,
requirements traceability checklist, quality gates, risk register, and initial AI
review evidence.

## Interaction 5 — Implement Phase 2

**Date:** 2026-08-27

**Prompt:**

> continue to phase 2

**Purpose:** Implement the typed flashcard model, both JSON input formats, complete
deck validation, friendly domain errors, and required loader tests.

**Result:** The first implementation passed all tests but retained the obsolete
generic `FileHandler` beside the new loader. Review rejected that duplication and
removed the legacy API and its tests. The refined loader passed its unit tests,
Black, isort, flake8, and mypy. Coverage could not yet be measured because the
active environment does not have the declared `pytest-cov` dependency installed.

## Interaction 6 — Implement Phase 3

**Date:** 2026-08-27

**Prompt:**

> Continue to phase 3

**Purpose:** Implement the Strategy and Factory patterns for sequential, random,
and adaptive quiz modes, including deterministic and misuse-path tests.

**Result:** The AI created a lifecycle-safe `QuizMode` interface, queue-backed
strategies, and `QuizModeFactory`. Review confirmed adaptive retries and defensive
deck copying. A formatting workflow conflict between default isort and Black was
found and corrected with shared settings in `pyproject.toml`. All 34 active tests
and the Phase 3 lint, format, and type checks pass.

## Interaction 7 — Implement Phase 4

**Date:** 2026-08-27

**Prompt:**

> Continue to phase 4

**Purpose:** Build the session engine, statistics, terminal UI, `argparse` CLI,
colored feedback, running stats, final summary, and graceful exit behavior.

**Result:** The implementation replaced the generic task-manager entry point and
added testable domain and UI layers. The initial test run exposed two incorrect
test expectations: an overly narrow one-third approximation and miscounted table
padding. Those expectations were fixed without changing correct production logic.
Repository-wide checks then exposed supplied extensionless `.claude` prompt files
and unformatted package markers; tooling configuration and formatting were refined.
The final active suite has 41 passing tests, and isort, Black, flake8, and mypy pass.

## Interaction 8 — Implement Phase 5

**Date:** 2026-08-27

**Prompt:**

> Continue to phase 5

**Purpose:** Add a useful sample deck and complete end-to-end, adaptive, early-exit,
and invalid-data test coverage through the real CLI composition path.

**Result:** The AI added `data/python_basics.json` and integration tests that drive
JSON loading, strategy creation, answer input, feedback, running stats, final stats,
and CLI exit codes. Unicode case folding and internal-whitespace behavior were also
tested. All 49 tests and current static checks pass. The required adaptive command
was played manually; one missed card was repeated and the nine-attempt session
reported 88.9% accuracy correctly.

## Interaction 9 — Execute Phase 6 Quality Gates

**Date:** 2026-08-27

**Prompt:**

> Continue to phase 6

**Purpose:** Run formatting, linting, type checking, tests, coverage, and manual
acceptance checks, then refine anything that prevents reproducible verification.

**Result:** Existing static checks and 49 tests passed immediately. Coverage tooling
was declared but missing, so it was installed into an isolated temporary directory
after sandboxed network access failed. Application and whole-project coverage both
measured 99%, and an HTML report was generated. Sequential, random, adaptive,
`exit`, and Ctrl+C paths passed manual terminal tests. Unused starter dependencies
were removed and the evidence was recorded in `docs/quality_report.md`.

## Interaction 10 — Complete Phase 7 Documentation

**Date:** 2026-08-27

**Prompt:**

> Continue to phase 7

**Purpose:** Replace generic starter documentation with accurate installation,
usage, architecture, design-pattern, quality, collaboration, and reflection content.

**Result:** The README and design-pattern guide were rewritten for Flashcard
Quizzer. A 1,243-word final report was completed, the AI edit log was cleaned of its
generic task-manager example, and documentation metrics were finalized. The only
personalization left is the student's name in the report header, which was not
inferred from the machine environment.

## Interaction 11 — Perform Phase 8 Submission Audit

**Date:** 2026-08-27

**Prompt:**

> Continue to phase 8

**Purpose:** Audit every rubric requirement, verify submission artifacts and named
tests, prepare Git tracking, and identify only genuinely user-owned final actions.

**Result:** The audit found that the starter `.gitignore` excluded the required
sample deck and HTML coverage artifact; those exclusions were removed and normal
caches remained ignored. A local Git repository was initialized on `main` after
managed-filesystem permission was granted. All 49 tests and static checks passed
again. The two remaining user actions were identified: provide the student name and
publish the repository to GitHub. The internal audit checklist was later removed
from the submission contents at the user's request.
