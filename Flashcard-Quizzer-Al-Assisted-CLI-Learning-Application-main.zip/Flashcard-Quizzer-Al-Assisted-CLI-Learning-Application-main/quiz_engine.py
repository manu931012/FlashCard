"""Quiz mode strategies and construction factory."""

import random
from abc import ABC, abstractmethod
from collections import deque
from typing import Callable, Deque, Dict, Optional, Sequence

from models import Flashcard, SessionStats


class QuizModeStateError(RuntimeError):
    """Raised when a quiz mode is used in an invalid lifecycle state."""


class QuizMode(ABC):
    """Strategy interface for selecting cards and processing their results."""

    @abstractmethod
    def get_next_card(self) -> Optional[Flashcard]:
        """Return the next card, or ``None`` when the mode is complete."""

    @abstractmethod
    def record_result(self, is_correct: bool) -> None:
        """Record the result for the most recently returned card."""


class _QueueQuizMode(QuizMode, ABC):
    """Shared lifecycle management for queue-backed quiz strategies."""

    def __init__(self, cards: Sequence[Flashcard]) -> None:
        """Initialize the strategy with a defensive copy of the card sequence."""

        self._cards: Deque[Flashcard] = deque(cards)
        self._current_card: Optional[Flashcard] = None

    def get_next_card(self) -> Optional[Flashcard]:
        """Return the next queued card after the prior result is recorded."""

        if self._current_card is not None:
            raise QuizModeStateError(
                "Record the current card's result before requesting another card."
            )
        if not self._cards:
            return None

        self._current_card = self._cards.popleft()
        return self._current_card

    def record_result(self, is_correct: bool) -> None:
        """Process and clear the result for the current card."""

        if self._current_card is None:
            raise QuizModeStateError("Request a card before recording a quiz result.")

        self._handle_result(self._current_card, is_correct)
        self._current_card = None

    @abstractmethod
    def _handle_result(self, card: Flashcard, is_correct: bool) -> None:
        """Apply strategy-specific behavior for a completed attempt."""


class SequentialMode(_QueueQuizMode):
    """Serve every flashcard once in its original order."""

    def _handle_result(self, card: Flashcard, is_correct: bool) -> None:
        """Consume the current card without changing the remaining queue."""


class RandomMode(_QueueQuizMode):
    """Serve every flashcard once in shuffled order."""

    def __init__(
        self,
        cards: Sequence[Flashcard],
        randomizer: Optional[random.Random] = None,
    ) -> None:
        """Shuffle a copy of the cards using an optionally injected generator."""

        shuffled_cards = list(cards)
        (randomizer or random.Random()).shuffle(shuffled_cards)
        super().__init__(shuffled_cards)

    def _handle_result(self, card: Flashcard, is_correct: bool) -> None:
        """Consume the current card without changing the remaining queue."""


class AdaptiveMode(_QueueQuizMode):
    """Repeat incorrectly answered cards after the initial queued cards."""

    def _handle_result(self, card: Flashcard, is_correct: bool) -> None:
        """Append an incorrect card to the retry queue."""

        if not is_correct:
            self._cards.append(card)


class QuizModeFactory:
    """Create a quiz strategy from a user-facing mode name."""

    @staticmethod
    def create_mode(
        mode_name: str,
        cards: Sequence[Flashcard],
        randomizer: Optional[random.Random] = None,
    ) -> QuizMode:
        """Return the strategy matching ``mode_name``.

        Args:
            mode_name: Sequential, random, or adaptive, matched case-insensitively.
            cards: Cards to provide to the selected strategy.
            randomizer: Optional deterministic generator used by random mode.

        Raises:
            ValueError: If ``mode_name`` is not supported.
        """

        creators: Dict[str, Callable[[], QuizMode]] = {
            "sequential": lambda: SequentialMode(cards),
            "random": lambda: RandomMode(cards, randomizer),
            "adaptive": lambda: AdaptiveMode(cards),
        }
        normalized_name = mode_name.strip().casefold()

        try:
            return creators[normalized_name]()
        except KeyError as error:
            supported_modes = ", ".join(creators)
            raise ValueError(
                f"Unknown quiz mode '{mode_name}'. Choose from: {supported_modes}."
            ) from error


class QuizEngineStateError(RuntimeError):
    """Raised when the session engine is used in an invalid state."""


class QuizEngine:
    """Coordinate answer checking, a quiz strategy, and session statistics."""

    def __init__(self, mode: QuizMode) -> None:
        """Initialize a quiz session using the supplied card-selection strategy."""

        self._mode = mode
        self._current_card: Optional[Flashcard] = None
        self.stats = SessionStats()

    def get_next_card(self) -> Optional[Flashcard]:
        """Return the next card when no unanswered card is active."""

        if self._current_card is not None:
            raise QuizEngineStateError(
                "Answer the current card before requesting another card."
            )

        self._current_card = self._mode.get_next_card()
        return self._current_card

    def submit_answer(self, answer: str) -> bool:
        """Check an answer, record its result, and return whether it is correct."""

        if self._current_card is None:
            raise QuizEngineStateError("Request a card before submitting an answer.")

        card = self._current_card
        is_correct = _normalize_answer(answer) == _normalize_answer(card.back)
        self._mode.record_result(is_correct)
        self.stats.record_attempt(card, is_correct)
        self._current_card = None
        return is_correct


def _normalize_answer(answer: str) -> str:
    """Normalize surrounding whitespace and letter case for comparison."""

    return answer.strip().casefold()
