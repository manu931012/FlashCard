"""Tests for command-line argument handling and friendly startup errors."""

from pathlib import Path

import pytest

from main import build_parser, main


def test_parser_uses_sequential_mode_by_default() -> None:
    """Default to sequential mode while leaving running stats disabled."""

    arguments = build_parser().parse_args(["--file", "deck.json"])

    assert arguments.file == "deck.json"
    assert arguments.mode == "sequential"
    assert arguments.stats is False


def test_parser_rejects_unknown_mode() -> None:
    """Let argparse reject an unsupported mode before application construction."""

    with pytest.raises(SystemExit) as error:
        build_parser().parse_args(["--file", "deck.json", "--mode", "unknown"])

    assert error.value.code == 2


def test_main_reports_missing_file_without_traceback(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Return a usage-style error code and concise message for a missing deck."""

    exit_code = main(["--file", str(tmp_path / "missing.json")])
    captured = capsys.readouterr()

    assert exit_code == 2
    assert "Error: Flashcard file not found" in captured.err
    assert "Traceback" not in captured.err
    assert captured.out == ""
