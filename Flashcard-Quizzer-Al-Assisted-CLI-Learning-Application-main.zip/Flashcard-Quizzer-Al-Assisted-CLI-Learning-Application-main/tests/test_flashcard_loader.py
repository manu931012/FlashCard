"""Tests for loading and validating flashcard JSON files."""

import json
from pathlib import Path
from typing import Any

import pytest

from models import Flashcard
from utils.file_handler import FlashcardDataError, load_flashcards


def _write_json(path: Path, data: Any) -> None:
    """Write JSON test data to a temporary file."""

    path.write_text(json.dumps(data), encoding="utf-8")


def test_load_valid_flashcards_array(tmp_path: Path) -> None:
    """Load cards from the required top-level array format."""

    deck_path = tmp_path / "array.json"
    _write_json(
        deck_path,
        [
            {"front": " CPU ", "back": " Central Processing Unit "},
            {"front": "RAM", "back": "Random Access Memory", "hint": "Memory"},
        ],
    )

    cards = load_flashcards(deck_path)

    assert cards == [
        Flashcard("CPU", "Central Processing Unit"),
        Flashcard("RAM", "Random Access Memory"),
    ]


def test_load_valid_flashcards_object(tmp_path: Path) -> None:
    """Load cards from the required wrapper-object format."""

    deck_path = tmp_path / "object.json"
    _write_json(deck_path, {"cards": [{"front": "HTTP", "back": "Protocol"}]})

    assert load_flashcards(deck_path) == [Flashcard("HTTP", "Protocol")]


def test_load_invalid_json(tmp_path: Path) -> None:
    """Report malformed JSON as a friendly domain error."""

    deck_path = tmp_path / "broken.json"
    deck_path.write_text('{"cards": [', encoding="utf-8")

    with pytest.raises(FlashcardDataError, match="Invalid JSON.*line 1"):
        load_flashcards(deck_path)


def test_load_missing_required_field(tmp_path: Path) -> None:
    """Reject a card without the required back field."""

    deck_path = tmp_path / "missing-back.json"
    _write_json(deck_path, [{"front": "CPU"}])

    with pytest.raises(
        FlashcardDataError, match="Card 1 is missing required field 'back'"
    ):
        load_flashcards(deck_path)


@pytest.mark.parametrize(
    ("data", "message"),
    [
        ({"unexpected": []}, "must be a list or an object"),
        ({"cards": "not-a-list"}, "'cards' value must be a list"),
        ([], "must contain at least one card"),
        (["not-an-object"], "Card 1 must be an object"),
        ([{"back": "Answer"}], "missing required field 'front'"),
        ([{"front": 123, "back": "Answer"}], "'front' must be a string"),
        ([{"front": "Question", "back": False}], "'back' must be a string"),
        ([{"front": "   ", "back": "Answer"}], "'front' cannot be blank"),
        ([{"front": "Question", "back": "\t"}], "'back' cannot be blank"),
    ],
)
def test_load_rejects_invalid_structure(
    tmp_path: Path, data: Any, message: str
) -> None:
    """Reject invalid deck and card structures with specific messages."""

    deck_path = tmp_path / "invalid-structure.json"
    _write_json(deck_path, data)

    with pytest.raises(FlashcardDataError, match=message):
        load_flashcards(deck_path)


def test_load_missing_file(tmp_path: Path) -> None:
    """Report a missing input file without exposing its original exception."""

    deck_path = tmp_path / "missing.json"

    with pytest.raises(FlashcardDataError, match="Flashcard file not found"):
        load_flashcards(deck_path)


def test_load_unreadable_path(tmp_path: Path) -> None:
    """Report operating-system read failures as a friendly domain error."""

    with pytest.raises(FlashcardDataError, match="Could not read flashcard file"):
        load_flashcards(tmp_path)
