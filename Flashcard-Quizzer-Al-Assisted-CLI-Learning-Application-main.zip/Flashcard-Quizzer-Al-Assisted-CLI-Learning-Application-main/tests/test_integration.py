"""End-to-end tests for complete command-line quiz sessions."""

import json
from pathlib import Path
from typing import Any, Iterable, Iterator

import pytest

from main import main


def _write_deck(path: Path, data: Any) -> None:
    """Write a JSON deck used by an integration test."""

    path.write_text(json.dumps(data), encoding="utf-8")


def _install_answers(monkeypatch: pytest.MonkeyPatch, answers: Iterable[str]) -> None:
    """Replace terminal input with deterministic answers."""

    answer_iterator: Iterator[str] = iter(answers)

    def read_answer(prompt: str) -> str:
        """Return the next simulated terminal answer."""

        return next(answer_iterator)

    monkeypatch.setattr("builtins.input", read_answer)


def test_full_session(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Run three questions and verify feedback and final statistics."""

    deck_path = tmp_path / "three-cards.json"
    _write_deck(
        deck_path,
        [
            {"front": "One", "back": "1"},
            {"front": "Two", "back": "2"},
            {"front": "Three", "back": "3"},
        ],
    )
    _install_answers(monkeypatch, ["1", "wrong", " 3 "])

    exit_code = main(["--file", str(deck_path), "--mode", "sequential"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert captured.out.count("Correct!") == 2
    assert "Incorrect. Correct answer: 2" in captured.out
    assert "Total Questions      | 3" in captured.out
    assert "Accuracy             | 66.7%" in captured.out
    assert "Missed Terms         | Two" in captured.out
    assert captured.err == ""


def test_adaptive_session_repeats_incorrect_card(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Drive an adaptive retry through the complete application stack."""

    deck_path = tmp_path / "adaptive.json"
    _write_deck(
        deck_path,
        {
            "cards": [
                {"front": "One", "back": "1"},
                {"front": "Two", "back": "2"},
            ]
        },
    )
    _install_answers(monkeypatch, ["wrong", "2", "1"])

    exit_code = main(["-f", str(deck_path), "-m", "adaptive", "--stats"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert captured.out.count("Progress:") == 3
    assert "Total Questions      | 3" in captured.out
    assert "Accuracy             | 66.7%" in captured.out
    assert "Missed Terms         | One" in captured.out


def test_early_exit_returns_partial_session_stats(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Display statistics for submitted answers when the user exits early."""

    deck_path = tmp_path / "early-exit.json"
    _write_deck(
        deck_path,
        [
            {"front": "One", "back": "1"},
            {"front": "Two", "back": "2"},
        ],
    )
    _install_answers(monkeypatch, ["wrong", "exit"])

    exit_code = main(["-f", str(deck_path)])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "Quiz ended early." in captured.out
    assert "Total Questions      | 1" in captured.out
    assert "Accuracy             | 0.0%" in captured.out
    assert "Missed Terms         | One" in captured.out


@pytest.mark.parametrize(
    ("contents", "expected_message"),
    [
        ('{"cards": [', "Invalid JSON in flashcard file"),
        ('[{"front": "Question"}]', "missing required field 'back'"),
        ('{"cards": []}', "must contain at least one card"),
    ],
)
def test_invalid_deck_exits_cleanly(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    contents: str,
    expected_message: str,
) -> None:
    """Turn loader failures into concise CLI errors without starting a quiz."""

    deck_path = tmp_path / "invalid.json"
    deck_path.write_text(contents, encoding="utf-8")

    exit_code = main(["-f", str(deck_path)])
    captured = capsys.readouterr()

    assert exit_code == 2
    assert expected_message in captured.err
    assert "Traceback" not in captured.err
    assert captured.out == ""
