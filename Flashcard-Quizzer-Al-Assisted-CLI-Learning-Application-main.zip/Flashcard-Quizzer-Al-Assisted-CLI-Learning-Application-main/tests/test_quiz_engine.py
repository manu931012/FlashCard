"""Tests for answer evaluation and session statistics."""

from typing import List

import pytest

from models import Flashcard
from quiz_engine import AdaptiveMode, QuizEngine, QuizEngineStateError, SequentialMode


@pytest.fixture
def cards() -> List[Flashcard]:
    """Provide a small deck for engine tests."""

    return [
        Flashcard("CPU", "Central Processing Unit"),
        Flashcard("RAM", "Random Access Memory"),
    ]


def test_submit_answer_is_case_insensitive_and_trims_whitespace(
    cards: List[Flashcard],
) -> None:
    """Accept an answer with different case and surrounding whitespace."""

    engine = QuizEngine(SequentialMode(cards))
    engine.get_next_card()

    assert engine.submit_answer("  central processing UNIT  ") is True
    assert engine.stats.total_questions == 1
    assert engine.stats.correct_answers == 1
    assert engine.stats.accuracy == 100.0


def test_incorrect_answers_update_stats_and_unique_missed_terms(
    cards: List[Flashcard],
) -> None:
    """Count attempts while listing a repeatedly missed term only once."""

    engine = QuizEngine(AdaptiveMode(cards[:1]))

    engine.get_next_card()
    assert engine.submit_answer("wrong") is False
    engine.get_next_card()
    assert engine.submit_answer("") is False
    engine.get_next_card()
    assert engine.submit_answer("Central Processing Unit") is True

    assert engine.stats.total_questions == 3
    assert engine.stats.correct_answers == 1
    assert engine.stats.accuracy == pytest.approx(100 / 3)
    assert engine.stats.missed_terms == ["CPU"]


def test_engine_requires_current_card_before_answer(
    cards: List[Flashcard],
) -> None:
    """Reject an answer when no question has been requested."""

    engine = QuizEngine(SequentialMode(cards))

    with pytest.raises(QuizEngineStateError, match="Request a card"):
        engine.submit_answer("answer")


def test_engine_requires_answer_before_next_card(cards: List[Flashcard]) -> None:
    """Reject a second question request while the first remains unanswered."""

    engine = QuizEngine(SequentialMode(cards))
    engine.get_next_card()

    with pytest.raises(QuizEngineStateError, match="Answer the current card"):
        engine.get_next_card()


def test_engine_returns_none_after_session_completion(
    cards: List[Flashcard],
) -> None:
    """Return no next card after every sequential card has been answered."""

    engine = QuizEngine(SequentialMode(cards[:1]))

    assert engine.get_next_card() == cards[0]
    engine.submit_answer(cards[0].back)

    assert engine.get_next_card() is None


def test_zero_attempt_session_has_zero_accuracy() -> None:
    """Avoid division by zero when a session contains no attempts."""

    engine = QuizEngine(SequentialMode([]))

    assert engine.stats.total_questions == 0
    assert engine.stats.accuracy == 0.0


def test_answer_comparison_uses_unicode_casefold() -> None:
    """Use Unicode-aware case folding rather than ASCII-oriented lowercasing."""

    engine = QuizEngine(SequentialMode([Flashcard("Street", "Straße")]))
    engine.get_next_card()

    assert engine.submit_answer("STRASSE") is True


def test_answer_comparison_preserves_internal_whitespace() -> None:
    """Do not silently accept an answer with different internal whitespace."""

    engine = QuizEngine(SequentialMode([Flashcard("Term", "two words")]))
    engine.get_next_card()

    assert engine.submit_answer("two  words") is False
