"""Tests for quiz strategies and the quiz mode factory."""

import random
from typing import List

import pytest

from models import Flashcard
from quiz_engine import (
    AdaptiveMode,
    QuizModeFactory,
    QuizModeStateError,
    RandomMode,
    SequentialMode,
)


@pytest.fixture
def cards() -> List[Flashcard]:
    """Provide a small deterministic flashcard deck."""

    return [
        Flashcard("One", "1"),
        Flashcard("Two", "2"),
        Flashcard("Three", "3"),
        Flashcard("Four", "4"),
    ]


@pytest.mark.parametrize(
    ("mode_name", "expected_type"),
    [
        ("sequential", SequentialMode),
        (" RANDOM ", RandomMode),
        ("Adaptive", AdaptiveMode),
    ],
)
def test_quiz_mode_factory(
    cards: List[Flashcard], mode_name: str, expected_type: type
) -> None:
    """Return the correct concrete strategy for every supported mode name."""

    mode = QuizModeFactory.create_mode(mode_name, cards, random.Random(7))

    assert isinstance(mode, expected_type)


def test_quiz_mode_factory_rejects_unknown_mode(cards: List[Flashcard]) -> None:
    """Reject unsupported mode names with a helpful list of valid choices."""

    with pytest.raises(ValueError, match="Choose from: sequential, random, adaptive"):
        QuizModeFactory.create_mode("spaced", cards)


def test_sequential_mode_preserves_order(cards: List[Flashcard]) -> None:
    """Serve cards in their source order and consume incorrect cards once."""

    mode = SequentialMode(cards)
    served_cards = []

    while (card := mode.get_next_card()) is not None:
        served_cards.append(card)
        mode.record_result(is_correct=False)

    assert served_cards == cards


def test_random_mode_shuffles_copy_without_losing_cards(
    cards: List[Flashcard],
) -> None:
    """Shuffle deterministically without changing the caller's deck."""

    original_cards = cards.copy()
    mode = RandomMode(cards, random.Random(7))
    served_cards = []

    while (card := mode.get_next_card()) is not None:
        served_cards.append(card)
        mode.record_result(is_correct=True)

    assert served_cards != original_cards
    assert set(served_cards) == set(original_cards)
    assert cards == original_cards


def test_adaptive_mode_behavior(cards: List[Flashcard]) -> None:
    """Repeat an incorrect card after initially queued cards until it is correct."""

    mode = AdaptiveMode(cards[:2])

    first_card = mode.get_next_card()
    mode.record_result(is_correct=False)
    second_card = mode.get_next_card()
    mode.record_result(is_correct=True)
    repeated_card = mode.get_next_card()
    mode.record_result(is_correct=True)

    assert first_card == cards[0]
    assert second_card == cards[1]
    assert repeated_card == cards[0]
    assert mode.get_next_card() is None


def test_adaptive_mode_requeues_each_incorrect_attempt(
    cards: List[Flashcard],
) -> None:
    """Continue retrying a card that is answered incorrectly more than once."""

    mode = AdaptiveMode(cards[:1])

    assert mode.get_next_card() == cards[0]
    mode.record_result(is_correct=False)
    assert mode.get_next_card() == cards[0]
    mode.record_result(is_correct=False)
    assert mode.get_next_card() == cards[0]
    mode.record_result(is_correct=True)

    assert mode.get_next_card() is None


def test_mode_requires_result_before_next_card(cards: List[Flashcard]) -> None:
    """Prevent callers from skipping a card without recording its result."""

    mode = SequentialMode(cards)
    mode.get_next_card()

    with pytest.raises(QuizModeStateError, match="Record the current card"):
        mode.get_next_card()


def test_mode_requires_card_before_result(cards: List[Flashcard]) -> None:
    """Prevent callers from recording a result when no attempt is active."""

    mode = SequentialMode(cards)

    with pytest.raises(QuizModeStateError, match="Request a card"):
        mode.record_result(is_correct=True)


def test_empty_mode_is_immediately_complete() -> None:
    """Allow an empty direct strategy safely even though the loader rejects it."""

    assert SequentialMode([]).get_next_card() is None
