"""Tests for terminal interaction, feedback, exits, and summaries."""

from typing import Callable, List

from models import Flashcard
from quiz_engine import QuizEngine, SequentialMode
from ui import GREEN, RED, RESET, TerminalUI


def _input_sequence(*answers: str) -> Callable[[str], str]:
    """Return an input function that provides answers in order."""

    answer_iterator = iter(answers)

    def read_answer(prompt: str) -> str:
        """Return the next configured answer."""

        return next(answer_iterator)

    return read_answer


def _raising_input(exception: BaseException) -> Callable[[str], str]:
    """Return an input function that raises the supplied terminal exception."""

    def read_answer(prompt: str) -> str:
        """Raise the configured exception."""

        raise exception

    return read_answer


def test_ui_displays_feedback_and_summary() -> None:
    """Render immediate feedback and all required summary fields."""

    cards = [Flashcard("One", "1"), Flashcard("Two", "2")]
    output: List[str] = []
    terminal = TerminalUI(
        QuizEngine(SequentialMode(cards)),
        use_color=False,
        input_function=_input_sequence("1", "wrong"),
        output_function=output.append,
    )

    stats = terminal.run()
    rendered_output = "\n".join(output)

    assert "Correct!" in rendered_output
    assert "Incorrect. Correct answer: 2" in rendered_output
    assert "Total Questions      | 2" in rendered_output
    assert "Accuracy             | 50.0%" in rendered_output
    assert "Missed Terms         | Two" in rendered_output
    assert stats.total_questions == 2


def test_ui_displays_running_stats_when_requested() -> None:
    """Show progress after each answer only when --stats behavior is enabled."""

    output: List[str] = []
    terminal = TerminalUI(
        QuizEngine(SequentialMode([Flashcard("One", "1")])),
        show_running_stats=True,
        use_color=False,
        input_function=_input_sequence("1"),
        output_function=output.append,
    )

    terminal.run()

    assert "Progress: 1/1 correct (100.0%)" in output


def test_ui_exit_ends_without_counting_attempt() -> None:
    """Treat a case-insensitive exit command as a clean early session end."""

    output: List[str] = []
    terminal = TerminalUI(
        QuizEngine(SequentialMode([Flashcard("One", "1")])),
        use_color=False,
        input_function=_input_sequence(" EXIT "),
        output_function=output.append,
    )

    stats = terminal.run()

    assert stats.total_questions == 0
    assert "Quiz ended early." in output
    assert "Missed Terms         | None" in "\n".join(output)


def test_ui_handles_keyboard_interrupt() -> None:
    """End cleanly when terminal input raises Ctrl+C."""

    output: List[str] = []
    terminal = TerminalUI(
        QuizEngine(SequentialMode([Flashcard("One", "1")])),
        use_color=False,
        input_function=_raising_input(KeyboardInterrupt()),
        output_function=output.append,
    )

    stats = terminal.run()

    assert stats.total_questions == 0
    assert "\nQuiz ended early." in output


def test_ui_handles_end_of_input() -> None:
    """End cleanly when piped input reaches EOF."""

    output: List[str] = []
    terminal = TerminalUI(
        QuizEngine(SequentialMode([Flashcard("One", "1")])),
        use_color=False,
        input_function=_raising_input(EOFError()),
        output_function=output.append,
    )

    terminal.run()

    assert "\nQuiz ended early." in output


def test_ui_uses_green_and_red_feedback_colors() -> None:
    """Apply the required ANSI colors when color output is enabled."""

    output: List[str] = []
    terminal = TerminalUI(
        QuizEngine(SequentialMode([Flashcard("One", "1"), Flashcard("Two", "2")])),
        use_color=True,
        input_function=_input_sequence("1", "wrong"),
        output_function=output.append,
    )

    terminal.run()

    assert f"{GREEN}Correct!{RESET}" in output
    assert f"{RED}Incorrect. Correct answer: 2{RESET}" in output
