"""Terminal user interface for interactive flashcard sessions."""

from typing import Callable, Optional

from models import SessionStats
from quiz_engine import QuizEngine

InputFunction = Callable[[str], str]
OutputFunction = Callable[[str], None]

GREEN = "\033[32m"
RED = "\033[31m"
RESET = "\033[0m"


class TerminalUI:
    """Run a quiz engine through injectable terminal input and output functions."""

    def __init__(
        self,
        engine: QuizEngine,
        show_running_stats: bool = False,
        use_color: bool = True,
        input_function: Optional[InputFunction] = None,
        output_function: Optional[OutputFunction] = None,
    ) -> None:
        """Configure the terminal UI and its testable I/O dependencies."""

        self._engine = engine
        self._show_running_stats = show_running_stats
        self._use_color = use_color
        self._input = input_function or input
        self._output = output_function or print

    def run(self) -> SessionStats:
        """Run the interactive quiz and always display a final summary."""

        self._output("Flashcard Quizzer — type 'exit' at any time to finish.")

        while True:
            card = self._engine.get_next_card()
            if card is None:
                break

            try:
                answer = self._input(f"Front: {card.front}\nYour answer: ")
            except (KeyboardInterrupt, EOFError):
                self._output("\nQuiz ended early.")
                break

            if answer.strip().casefold() == "exit":
                self._output("Quiz ended early.")
                break

            is_correct = self._engine.submit_answer(answer)
            if is_correct:
                self._output(self._colorize("Correct!", GREEN))
            else:
                feedback = f"Incorrect. Correct answer: {card.back}"
                self._output(self._colorize(feedback, RED))

            if self._show_running_stats:
                self._display_running_stats()

        self._display_summary()
        return self._engine.stats

    def _display_running_stats(self) -> None:
        """Display compact statistics after the latest submitted answer."""

        stats = self._engine.stats
        self._output(
            f"Progress: {stats.correct_answers}/{stats.total_questions} correct "
            f"({stats.accuracy:.1f}%)"
        )

    def _display_summary(self) -> None:
        """Display the required end-of-session summary table."""

        stats = self._engine.stats
        missed_terms = ", ".join(stats.missed_terms) if stats.missed_terms else "None"
        self._output("\nSession Summary")
        self._output("-" * 42)
        self._output(f"{'Total Questions':<20} | {stats.total_questions}")
        self._output(f"{'Accuracy':<20} | {stats.accuracy:.1f}%")
        self._output(f"{'Missed Terms':<20} | {missed_terms}")

    def _colorize(self, message: str, color: str) -> str:
        """Apply an ANSI color only when color output is enabled."""

        if not self._use_color:
            return message
        return f"{color}{message}{RESET}"
