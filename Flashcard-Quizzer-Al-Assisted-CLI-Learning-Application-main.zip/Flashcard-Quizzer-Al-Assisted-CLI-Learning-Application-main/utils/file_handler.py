"""JSON file handling and flashcard validation utilities."""

import json
from pathlib import Path
from typing import Any, List, Union

from models import Flashcard


class FlashcardDataError(Exception):
    """Raised when a flashcard file cannot be read or validated."""


def load_flashcards(file_path: Union[str, Path]) -> List[Flashcard]:
    """Load and validate flashcards from a JSON file.

    The JSON root may be either a list of card objects or an object containing a
    ``cards`` list. Expected file and validation failures are converted to
    :class:`FlashcardDataError` so callers can show a helpful message without a
    traceback.

    Args:
        file_path: Path to the UTF-8 JSON flashcard file.

    Returns:
        A non-empty list of validated flashcards.

    Raises:
        FlashcardDataError: If the file cannot be read, decoded, or validated.
    """

    path = Path(file_path)
    try:
        with path.open("r", encoding="utf-8") as file:
            raw_data: Any = json.load(file)
    except FileNotFoundError as error:
        raise FlashcardDataError(f"Flashcard file not found: {path}") from error
    except json.JSONDecodeError as error:
        raise FlashcardDataError(
            f"Invalid JSON in flashcard file at line {error.lineno}, "
            f"column {error.colno}."
        ) from error
    except OSError as error:
        raise FlashcardDataError(f"Could not read flashcard file: {path}") from error

    card_items = _extract_card_items(raw_data)
    return [_validate_card(item, index) for index, item in enumerate(card_items, 1)]


def _extract_card_items(raw_data: Any) -> List[Any]:
    """Extract the card list from either supported top-level JSON format."""

    if isinstance(raw_data, list):
        card_items = raw_data
    elif isinstance(raw_data, dict) and "cards" in raw_data:
        card_items = raw_data["cards"]
        if not isinstance(card_items, list):
            raise FlashcardDataError("The 'cards' value must be a list.")
    else:
        raise FlashcardDataError(
            "Flashcard JSON must be a list or an object containing a 'cards' list."
        )

    if not card_items:
        raise FlashcardDataError("The flashcard deck must contain at least one card.")

    return card_items


def _validate_card(raw_card: Any, position: int) -> Flashcard:
    """Validate one decoded card and convert it to a domain model."""

    if not isinstance(raw_card, dict):
        raise FlashcardDataError(f"Card {position} must be an object.")

    for field_name in ("front", "back"):
        if field_name not in raw_card:
            raise FlashcardDataError(
                f"Card {position} is missing required field '{field_name}'."
            )

        field_value = raw_card[field_name]
        if not isinstance(field_value, str):
            raise FlashcardDataError(
                f"Card {position} field '{field_name}' must be a string."
            )
        if not field_value.strip():
            raise FlashcardDataError(
                f"Card {position} field '{field_name}' cannot be blank."
            )

    return Flashcard(front=raw_card["front"].strip(), back=raw_card["back"].strip())
